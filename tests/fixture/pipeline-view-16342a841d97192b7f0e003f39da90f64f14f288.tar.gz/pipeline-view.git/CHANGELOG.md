# CHANGELOG
 This changelog was created automatically. resistance is futile.


## 2015-05-12

 *    Adding pipeline view (Alberto Guimarães Viana)   
