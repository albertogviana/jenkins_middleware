# CHANGELOG
 This changelog was created automatically. resistance is futile.


## 2015-07-28

 *    Adding e-mail notification (Alberto Guimarães Viana)   


## 2015-07-20

 *    Made replace script executable again. (mbecker1)   


## 2015-07-17

 *    Updated replace script for RUNNING_ON_NODES and updated README (mbecker1)   
 *    Added the new config.xml for adding optional slaves. (mbecker1)   


## 2015-06-16

 *    updated CHANGELOG.md (Tobias Wiesenthal)   
 *    changes in config.xml according to WDP-98 (Tobias Wiesenthal)   


## 2015-05-27

 *    Added workspace property (mbecker1)   
 *    updated config.xml so it uses the new location of the build.xml (Tobias Wiesenthal)   


## 2015-05-12

 *    Updated replace script. (mbecker1)   
 *    Updated replace script. (mbecker1)   


## 2015-05-08

 *    removed artifact  creation for this job (Tobias Wiesenthal)   
 *    Updated CHANGELOG. (mbecker1)   
 *    Updated README (How to create this job) and VERSION. (mbecker1)   


## 2015-05-07

 *    Fixed indent. (Marvin Becker)   


## 2015-05-06

 *    added example json for this job to README.md (Tobias Wiesenthal)   
 *    Removed CopyArtifact part from config.xml. (mbecker1)   


## 2015-05-05

 *    updated CHANGELOG.md (Tobias Wiesenthal)   
 *    renamed:    replace.php -> replace (Tobias Wiesenthal)   
 *    Added .gitignore. (mbecker1)   
 *    Added shebang to replace script. Made it executable.o (mbecker1)   
 *    Added script for placeholder replacement. (mbecker1)   
 *    Added CHANGELOG. (mbecker1)   
 *    Added job config.xml. (mbecker1)   
 *    Removed dummy files. Added README. (mbecker1)   
 *    Added skeleton. Finished build.xml. (mbecker1)   
