# README
# General
This abstract job can be used to create a start job for a Jenkins pipeline.

Its only concern is to pass the parameters to the next job (checkout in most cases).

# Tag version changelog
- v1.1.0
  - Added optional placeholder RUNNING_ON_NODES

- v1.0.1
  - Keep only last 10 builds for each pipeline

- v1.0.0
  - first working version

# Included
No binaries included.

# How To Execute Ant
The ant script does nothing right now.

# Example json to create this job

```json
{
    "format_version":"1.0",
    "job":{
        "name":"crazyJob",
        "abstract_name":"start",
        "version":"v*"
    },
    "placeholder":{
        "REPO_URL":"git@source.services.ggs-net.com:my-team/our-project.git",
        "BRANCH_NAME":"develop",
        "DOWNSTREAM_PROJECT":"my-team-our-project-develop-something,my-team-our-project-develop-something-else",
        "EMAIL": "my-team@goodgamestudios.com"
    }
}
```

## Placeholders
- `REPO_URL`: the git repository.
- `BRANCH_NAME`: the branch to checkout.
- `DOWNSTREAM_PROJECT`: the downstream project(s).
- `EMAIL`: if the build fail or be unstable it will send a mail to inform the team.
- `RUNNING_ON_NODES` : (optional) Enter here one or more labels (using && or ||) to set the nodes this job can run on
- `EMAIL`: (optional) email where to send a notification if the job fails or unstable
