# CHANGELOG
 This changelog was created automatically. resistance is futile.


## 2015-06-16

 *    changes in config.xml according to WDP-98 (Tobias Wiesenthal)   


## 2015-05-27

 *    update config.xml and build.xml if needed (Tobias Wiesenthal)   
 *    updated config.xml so it uses the new location of the build.xml (Tobias Wiesenthal)   


## 2015-05-20

 *    updated CHANGELOG.md (Tobias Wiesenthal)   
 *    added creation of a "clone workspace scm" artifact (Tobias Wiesenthal)   
 *    updated CHANGELOG.md (Tobias Wiesenthal)   
 *    added creation of a "clone workspace scm" artifact (Tobias Wiesenthal)   
 *    fixed file permissions (Tobias Wiesenthal)   
 *    previously forgot commit this fix: fixed xml structure (Tobias Wiesenthal)   


## 2015-05-19

 *    updated CHANGELOG.md (Tobias Wiesenthal)   
 *    added execution of pre- and post- scripts if available (Tobias Wiesenthal)   


## 2015-05-12

 *    Updated replace script. (mbecker1)   
 *    Updated replace script. (mbecker1)   
 *    Updated replace script. (mbecker1)   


## 2015-05-08

 *    Enabled composer job by default. (mbecker1)   
 *    Remove extension (Alberto Guimarães Viana)   
 *    Updated CHANGELOG. (mbecker1)   
 *    Updated README (How to create this job) and VERSION. (mbecker1)   


## 2015-05-05

 *    Updated CHANGELOG. (mbecker1)   
 *    Added job config. (mbecker1)   
 *    Merged https://source.services.ggs-net.com/devops/ggs-ci-build-composer . Updated README. (mbecker1)   
 *    Initial commit. Added skeleton. (mbecker1)   
