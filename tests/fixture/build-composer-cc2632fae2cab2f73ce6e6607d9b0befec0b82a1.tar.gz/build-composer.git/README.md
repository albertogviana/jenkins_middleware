# README
# General
This abstract job can be used to create a Jenkins job for Composer.

It will execute ant to run Composer.

# Tag version changelog
- v1.2.0
  - Added optional placeholder RUNNING_ON_NODES

- v1.1.1
  - Remove Archive the artifacts option. Just leaving Archieve for Clone Workspace SCM

- v1.1.0
  - Update composer.phar if it was needed

- v1.0.2
  - Artifact clean up

- v1.0.1
  - Keep only last 10 builds for each pipeline

# Included
- Composer (in assets)
  - `Composer version 1.0-dev (42a9561ae23b236da1d5a4acf50f7ea96ebe68aa) 2015-05-02 23:10:29`

(It will use PHPUnit from vendor.)

# How To Execute Ant
From the workspace execute:

```
ant -f ../build.xml
```

# Example json to create this job

```json
{
    "format_version":"1.0",
    "job":{
        "name":"crazyJob",
        "abstract_name":"build-composer",
        "version":"master"
    },
    "placeholder":{
        "UPSTREAM_PROJECT":"my-upstream-project",
        "DOWNSTREAM_PROJECT":"my-downstream-project"
    }
}
```

## Placeholders
- `UPSTREAM_PROJECT`: the upstream project.
- `DOWNSTREAM_PROJECT`: the downstream project(s).
- `RUNNING_ON_NODES` : (optional) Enter here one or more labels (using && or ||) to set the nodes this job can run on
- `EMAIL`: (optional) email where to send a notification if the job fails or unstable
